
eng_num={"0":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\0_eng.mp3","1":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\1_eng.mp3","2":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\2_eng.wav","3":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\3_eng.wav","4":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\4_eng.mp3","5":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\5_eng.mp3","6":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\6_eng.wav","7":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\7_eng.mp3","8":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\8_eng.mp3","9":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\9_eng.mp3"}

eng_start = "C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\eng_start.wav"
eng_out_arv = "C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\outro_arv_eng.mp3  "

eng_out_dep_1= "C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\outro_dep_eng_1.wav"
eng_out_dep_2="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\english\\outro_dep_eng_2.wav"
