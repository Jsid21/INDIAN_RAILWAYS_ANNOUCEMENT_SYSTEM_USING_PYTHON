import tkinter as tk
from tkinter import ttk
from city import *
from Typ import *
from mar_attri import *
from eng_attri import *
from hindi_attri import *
from playsound import playsound


def submit():
    train_number = train_number_entry.get()
    source_station = source_station_combobox.get()
    destination_station = destination_station_combobox.get()
    train_type = Train_type_combobox.get()
    platform_number = platform_number_entry.get()
    announcement_type = announcement_var.get()
    repeat =repeatation_entry.get()

    try:
        submit_button.configure(state="disabled")
        print("Train Number:", train_number)
        print("Source Station:", source_station)
        print("Destination Station:", destination_station)
        print("Train type :", train_type)
        print("Platform Number:", platform_number,)
        print("Announcement Type:", announcement_type)
        print("repeat for :",repeat)
        print("------------------------------------------------")
        
        rp = int(repeat)
        r =1
        while r <= rp:
 
            mar_announce(train_number,announcement_type,platform_number,source_station,destination_station,train_type)
            hindi_announce(train_number,announcement_type,platform_number,source_station,destination_station,train_type)
            eng_announce(train_number,announcement_type,platform_number,source_station,destination_station,train_type)
            r+=1
            submit_button.configure(state="disabled")
    finally :
        submit_button.configure(state="normal")
    
bell1="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\railway_sms.mp3"
bell2="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\last bell.mp3"

def mar_announce(train_number,announcement_type,platform_number,source_station,destination_station,train_type):
    s1=cities.get(source_station)
    s2=cities.get(destination_station)
    d1 = mar_num.get(train_number[0])
    d2 = mar_num.get(train_number[1])
    d3 = mar_num.get(train_number[2])
    d4 = mar_num.get(train_number[3])
    d5 = mar_num.get(train_number[4])

    if announcement_type =="Arrival":
        mr_l1 = [bell1,mar_start,d1,d2,d3,d4,d5,s1,s2,typ.get(train_type),mar_out,mar_num.get(platform_number),mar_out_arv]
        for j in mr_l1 :
            playsound(j)
        
    elif announcement_type =="Departure":
        mr_l2 = [bell1,mar_start,d1,d2,d3,d4,d5,s1,s2,typ.get(train_type),mar_out,mar_num.get(platform_number),mar_out_dep,bell2]
        for k in mr_l2 :
            playsound(k)

def hindi_announce(train_number,announcement_type,platform_number,source_station,destination_station,train_type):
    s1=cities.get(source_station)
    s2=cities.get(destination_station)
    d1 = hindi_num.get(train_number[0])
    d2 = hindi_num.get(train_number[1])
    d3 = hindi_num.get(train_number[2])
    d4 = hindi_num.get(train_number[3])
    d5 = hindi_num.get(train_number[4])

    if announcement_type =="Arrival":
        hn_l1 = [hindi_start,d1,d2,d3,d4,d5,s1,s2,typ.get(train_type),hindi_out,hindi_num.get(platform_number),hindi_out_arv]
        for l in hn_l1 :
            playsound(l)
    elif announcement_type =="Departure":
        mr_l1 = [hindi_start,d1,d2,d3,d4,d5,s1,s2,typ.get(train_type),hindi_out,hindi_num.get(platform_number),hindi_out_dep,bell2]
        for m in mr_l1 :
            playsound(m)

def eng_announce(train_number,announcement_type,platform_number,source_station,destination_station,train_type):
    s1=cities.get(source_station)
    s2=cities.get(destination_station)
    d1 = eng_num.get(train_number[0])
    d2 = eng_num.get(train_number[1])
    d3 = eng_num.get(train_number[2])
    d4 = eng_num.get(train_number[3])
    d5 = eng_num.get(train_number[4])

    if announcement_type =="Arrival":
        en_l1 = [eng_start,d1,d2,d3,d4,d5,s1,s2,typ.get(train_type),eng_out_arv,eng_num.get(platform_number)]
        for n in en_l1 :
            playsound(n)
    elif announcement_type =="Departure":
        mr_l1 = [eng_start,d1,d2,d3,d4,d5,s1,s2,typ.get(train_type),eng_out_dep_1,eng_num.get(platform_number),eng_out_dep_2,bell2]
        for o in mr_l1 :
            playsound(o)




root = tk.Tk()
root.title("INDIAN RAILWAYS ANNOUNCEMENT SYSTEM")
root.geometry("400x400")

# Train Number
train_number_label = ttk.Label(root, text="TRAIN NUMBER")
train_number_label.pack()
train_number_entry = ttk.Entry(root,width="20")
train_number_entry.pack()

# Source Station
source_station_label = ttk.Label(root, text="SOURCE STATION",width="20")
source_station_label.pack()
source_station_combobox = ttk.Combobox(root, values=list(cities.keys()),width="20")
source_station_combobox.pack()
source_station = source_station_combobox.get()


# Destination Station
destination_station_label = ttk.Label(root, text="DESTINATION STATION",width="20")
destination_station_label.pack()
destination_station_combobox = ttk.Combobox(root, values=list(cities.keys()),width="20")
destination_station_combobox.pack()
destination_station = destination_station_combobox.get()

# train type
Train_type_label = ttk.Label(root, text="TRAIN TYPE :",width="20")
Train_type_label.pack()
Train_type_combobox = ttk.Combobox(root, values=list(typ.keys()),width="20")
Train_type_combobox.pack()

# Platform Number
platform_number_label = ttk.Label(root, text="PLATFORM",width="20")
platform_number_label.pack()
platform_number_entry = ttk.Entry(root,width="20")
platform_number_entry.pack()
# Announcement Type
announcement_label = ttk.Label(root, text="ANNOUNCEMT TYPE",width="20")
announcement_label.pack()
announcement_var = tk.StringVar()
arrival_radio = ttk.Radiobutton(root, text="Arrival", variable=announcement_var, value="Arrival")
arrival_radio.pack()
departure_radio = ttk.Radiobutton(root, text="Departure", variable=announcement_var, value="Departure")
departure_radio.pack()

# times play 
repeatation_label = ttk.Label(root, text="REPEAT FOR :",width="20")
repeatation_label.pack()
repeatation_entry = ttk.Entry(root,width="20")
repeatation_entry.pack()

# Submit Button
submit_button = ttk.Button(root, text="ANNOUCE", command=submit)
submit_button.pack()

# exit button
exit_button = ttk.Button(root, text="EXIT",command=root.destroy)
exit_button.pack()

root.mainloop()
