
mar_start="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\intro_mar.mp3"
mar_out = "C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\outro_arv_mar_1.mp3"
mar_out_arv = "C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\outro_arv_mar_2.mp3"
mar_out_dep="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\outro_dep.wav"
mar_num = {"0":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\0_hin.wav","1":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\1_mar.mp3","2":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\2_mar.mp3","3":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\3_mar.wav","4":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\4_mar.mp3","5":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\5_mar.mp3","6":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\6_mar.mp3","7":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\7_mar.mp3","8":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\8_mar.mp3","9":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\marathi\\9_mar.mp3"}

