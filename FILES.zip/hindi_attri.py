
hindi_start = "C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\intro hindi.mp3"
hindi_out="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\outro_arv_1_hn.wav"
hindi_out_dep ="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\outro_dep_hin_2.wav"
hindi_out_arv ="C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\outro_arv_2_hn.wav"

hindi_num={"0":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\0_hin.wav","1":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\1_mar.mp3","2":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\2_hin.wav","3":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\3_mar.wav","4":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\4_mar.mp3","5":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\5_mar.mp3","6":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\6_hin.wav","7":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\7_mar.mp3","8":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\8_mar.mp3","9":"C:\\Users\\ADMIN\\Documents\\IR PROJECT\\hindi\\9_mar.mp3"}
